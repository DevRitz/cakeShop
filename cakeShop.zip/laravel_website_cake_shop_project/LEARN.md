Using laravel, a cake shop project is done by me. CRUD of products, categories, cart system, admin CRUD etc are done which can be used as example even in other projects. 
For learning purpose, you can use this project freely and modify according to your need. As basic to intermediate operations are done here, it might come in handy. 
Do hit the star button if you like the project or it helps you in any way. Thanks in advance for that generous star press! <3


![Homepage](/images-of-the-sweet-piece-site/thesweetpiece.PNG)
